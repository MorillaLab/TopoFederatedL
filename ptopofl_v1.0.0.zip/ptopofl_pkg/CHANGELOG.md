# Changelog

All notable changes to pTopoFL are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] — 2025-01-01

### Added
- `pTopoFLClient`: local training with topology-guided sample weights
  and privacy-safe descriptor transmission.
- `pTopoFLServer`: topology-guided clustering, intra-cluster
  topology-weighted aggregation, inter-cluster consensus blending.
- `run_rounds`: convenience training loop.
- `ptopofl.tda`: pure NumPy/SciPy persistent homology engine
  (H0 exact via union-find, H1 approximated via triangle filtration).
- `ptopofl.baselines`: FedAvg, FedProx, SCAFFOLD, pFedMe.
- `ptopofl.data`: `make_healthcare_federated`, `make_benchmark_federated`.
- Full test suite (38 tests).
- Examples: `quickstart.py`, `full_comparison.py`.
- `CITATION.cff` and `.zenodo.json` for reproducible citation.

### Theoretical contributions (see paper)
- Theorem 1 (Information Contraction): PH descriptors leak strictly
  less mutual information per sample than gradients.
- Theorem 2 (Convergence): Wasserstein-weighted FL converges linearly;
  effective variance bounded by intra-cluster Wasserstein radii.
