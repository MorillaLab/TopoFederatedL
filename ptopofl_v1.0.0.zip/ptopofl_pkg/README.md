# pTopoFL

**Privacy-Preserving Personalised Federated Learning via Persistent Homology**

[![License: GPL-3.0](https://img.shields.io/badge/License-GPL--3.0-blue.svg)](LICENSE)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/)
[![NumPy only](https://img.shields.io/badge/TDA-pure%20NumPy%2FSciPy-green.svg)]()

Clients transmit compact **persistent homology descriptors** instead of gradients.  
The server performs **topology-guided clustering** and **Wasserstein-weighted aggregation**.  
Result: simultaneous privacy and non-IID performance — no noise, no accuracy trade-off.

| Scenario | pTopoFL | FedProx | FedAvg |
|----------|---------|---------|--------|
| Healthcare (8 hospitals, 2 adversarial) | **0.841** | 0.829 | 0.790 |
| Benchmark (10 clients, pathological non-IID) | **0.910** | 0.909 | 0.897 |
| Reconstruction risk | **0.0024** | 0.0107 | 0.0107 |

---

## Installation

```bash
pip install ptopofl
```

Or from source:

```bash
git clone https://github.com/MorillaLab/TopoFederatedL
cd TopoFederatedL
pip install -e .
```

**Dependencies:** `numpy >= 1.24`, `scipy >= 1.10`, `scikit-learn >= 1.3`  
No external TDA library (GUDHI, Ripser, Giotto-TDA) required.

---

## Quick start

```python
from ptopofl import pTopoFLClient, pTopoFLServer, run_rounds
from ptopofl.data import make_healthcare_federated

# 1. Non-IID data: 8 hospitals, 2 adversarial
data, _, _ = make_healthcare_federated(n_clients=8, adversarial_clients=[1, 5])

# 2. Each client holds only its own private data
clients = [
    pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
                  d["X_test"],   d["y_test"])
    for d in data
]

# 3. Server clusters clients by topological similarity (round 0)
server = pTopoFLServer(n_clusters=2, alpha_blend=0.3)
server.fit_clusters([c.get_descriptor() for c in clients])

# 4. Train for 15 rounds
accs, aucs = run_rounds(clients, server, n_rounds=15, verbose=True)
print(f"Final AUC: {aucs[-1]:.3f}")   # → 0.841
```

---

## How it works

**Each client** computes a topological descriptor from its local data:

```
φₖ = [Betti curves (H₀, H₁), persistence entropy, amplitude, feature counts]
     → 48-dimensional vector
```

This descriptor is **many-to-one**: infinitely many datasets share the same φₖ,
making inversion provably ill-posed (Theorem 1 in the paper).

**The server** runs a three-step aggregation:

```
Step 1  Topology-guided clustering (round 0 only)
        D_ij = ‖φ̂ᵢ − φ̂ⱼ‖₂   →   agglomerative clustering → C₁, …, Cₘ

Step 2  Intra-cluster aggregation
        wₖ ∝ nₖ · exp(−‖φ̂ₖ − φ̂_Cⱼ‖) · tₖ   (topology × size × trust)
        θ_Cⱼ = Σ wₖ θₖ

Step 3  Inter-cluster blending
        θ*_Cⱼ = (1−α) θ_Cⱼ + α θ̄          (α=0.3 by default)
```

---

## Baselines

```python
from ptopofl.baselines import (
    FedAvgClient,   FedAvgServer,
    FedProxClient,  FedProxServer,
    SCAFFOLDClient, SCAFFOLDServer,
    pFedMeClient,   pFedMeServer,
    run_baseline_rounds,
)

clients = [FedProxClient(d["client_id"], d["X_train"], d["y_train"],
                         d["X_test"],   d["y_test"], mu=0.1)
           for d in data]
server  = FedProxServer()
accs, aucs = run_baseline_rounds(clients, server, n_rounds=15)
```

---

## API reference

### `pTopoFLClient`

| Method | Description |
|--------|-------------|
| `get_descriptor()` | Returns privacy-safe topological summary (sent to server) |
| `train_local(cluster_params)` | Local training with topology-guided sample weights |
| `get_params()` | Model parameters for server aggregation |
| `set_params(params)` | Receive cluster model from server |
| `evaluate()` | Returns `{'accuracy': float, 'auc': float}` |

### `pTopoFLServer`

| Method | Description |
|--------|-------------|
| `fit_clusters(descriptors)` | Cluster clients by Wasserstein similarity (call once) |
| `aggregate(clients, round_num)` | One aggregation round; returns `(cluster_models, log)` |
| `cluster_params(client_id)` | Cluster sub-global model for a given client |

### `ptopofl.tda`

| Function | Description |
|----------|-------------|
| `compute_topological_descriptor(X)` | 48-dim descriptor from a dataset |
| `descriptor_distance(d1, d2)` | L2 distance between descriptors |
| `wasserstein_distance_diagrams(dgm1, dgm2)` | Wₚ distance between PD diagrams |
| `persistence_entropy(pairs)` | Shannon entropy of persistence values |
| `diagram_amplitude(pairs)` | L² amplitude of a diagram |
| `betti_curve(pairs, thresholds)` | Betti curve at given thresholds |

---

## Reproduce paper results

```bash
python examples/full_comparison.py
```

Expected output (~3 min on CPU):
```
Healthcare — pTopoFL AUC: 0.8410
Benchmark  — pTopoFL AUC: 0.9100
```

---

## Run tests

```bash
pip install pytest
pytest tests/ -v
```

---

## Citation

```bibtex
@article{morilla2025ptopofl,
  title   = {{pTopoFL}: Privacy-Preserving Personalised Federated Learning
             via Persistent Homology},
  author  = {Morilla, Ian and Ginot, Gr{\'e}gory},
  year    = {2025},
  url     = {https://github.com/MorillaLab/TopoFederatedL}
}
```

---

## Funding

Consejería de Universidades, Ciencias y Desarrollo and FEDER funds,
Junta de Andalucía (ProyExec\_0499).  
ANR-18-IDEX-0001 (Université Paris Cité IdEx, France 2030).

**License:** GPL-3.0
