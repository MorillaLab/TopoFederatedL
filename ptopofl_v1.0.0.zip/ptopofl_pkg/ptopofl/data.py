"""
ptopofl.data
============
Synthetic non-IID federated data generators for pTopoFL experiments.

Functions
---------
make_healthcare_federated(n_clients, ...) -> (client_data, X_test, y_test)
    Scenario A: 8 hospitals with heterogeneous patient distributions.
    Binary classification: year-1 mortality post-lung-transplant.
    Optional adversarial clients with label-flip poisoning.

make_benchmark_federated(n_clients, ...) -> (client_data, X_test, y_test)
    Scenario B: classic pathological non-IID FL stress test.
    Each client has severely skewed class distribution.

Both return a list of client dicts with keys:
    client_id, X_train, y_train, X_test, y_test, is_adversarial, n_train
"""

from __future__ import annotations

import numpy as np
from sklearn.datasets import make_classification


def make_healthcare_federated(
    n_clients:            int             = 8,
    n_samples_per_client: list[int] | None = None,
    n_features:           int             = 20,
    n_informative:        int             = 10,
    adversarial_clients:  list[int] | None = None,
    adversarial_fraction: float            = 0.30,
    global_test_size:     int             = 500,
    random_state:         int             = 42,
) -> tuple[list[dict], np.ndarray, np.ndarray]:
    """
    Generate a non-IID federated healthcare dataset.

    Each client simulates a hospital with:
    - A distinct class-imbalance (mortality rate 10–45 %).
    - A shifted and scaled feature distribution.
    - Optional label-flip adversarial poisoning.

    Parameters
    ----------
    n_clients            : int   Number of hospital clients.
    n_samples_per_client : list  Sample counts.  Defaults to Uniform(60, 250).
    n_features           : int   Total features.
    n_informative        : int   Informative features.
    adversarial_clients  : list  Client indices that apply label-flip attacks.
    adversarial_fraction : float Fraction of labels flipped on adversarial clients.
    global_test_size     : int   Size of the shared IID global test set.
    random_state         : int

    Returns
    -------
    client_data  : list of dicts, one per client.
    X_test_global: ndarray (global_test_size, n_features)
    y_test_global: ndarray (global_test_size,)

    Each client dict has keys:
        client_id, X_train, y_train, X_test, y_test,
        is_adversarial, mortality_rate, n_train.
    """
    rng = np.random.RandomState(random_state)

    if n_samples_per_client is None:
        n_samples_per_client = rng.randint(60, 250, size=n_clients).tolist()
    if adversarial_clients is None:
        adversarial_clients = []

    # Global feature space
    X_g, y_g = make_classification(
        n_samples=10_000, n_features=n_features,
        n_informative=n_informative, n_redundant=4,
        n_classes=2, flip_y=0.02, class_sep=1.0,
        random_state=random_state,
    )
    idx_test     = rng.choice(len(X_g), global_test_size, replace=False)
    X_test_glob  = X_g[idx_test]
    y_test_glob  = y_g[idx_test]

    # Per-client heterogeneity
    rates = np.linspace(0.10, 0.45, n_clients)
    rng.shuffle(rates)
    pos_idx = np.where(y_g == 1)[0]
    neg_idx = np.where(y_g == 0)[0]

    client_data: list[dict] = []
    for c in range(n_clients):
        n    = int(n_samples_per_client[c])
        rate = float(rates[c])
        shift = rng.randn(n_features) * 0.5
        scale = rng.uniform(0.7, 1.4, n_features)

        n_pos = max(1, int(n * rate))
        n_neg = n - n_pos
        ps = rng.choice(pos_idx, n_pos, replace=True)
        ns = rng.choice(neg_idx, n_neg, replace=True)

        X_c = np.vstack([X_g[ps] * scale + shift,
                         X_g[ns] * scale + shift * 0.3])
        y_c = np.hstack([np.ones(n_pos), np.zeros(n_neg)])

        perm = rng.permutation(len(X_c))
        X_c, y_c = X_c[perm], y_c[perm]

        if c in adversarial_clients:
            n_flip = int(adversarial_fraction * len(y_c))
            flip   = rng.choice(len(y_c), n_flip, replace=False)
            y_c[flip] = 1.0 - y_c[flip]

        n_test  = max(30, int(len(X_c) * 0.2))
        t_idx   = rng.choice(len(X_c), n_test, replace=False)
        tr_idx  = np.setdiff1d(np.arange(len(X_c)), t_idx)

        client_data.append({
            "client_id":      c,
            "X_train":        X_c[tr_idx],
            "y_train":        y_c[tr_idx],
            "X_test":         X_c[t_idx],
            "y_test":         y_c[t_idx],
            "is_adversarial": c in adversarial_clients,
            "mortality_rate": rate,
            "n_train":        len(tr_idx),
        })

    return client_data, X_test_glob, y_test_glob


def make_benchmark_federated(
    n_clients:     int   = 10,
    n_samples_total: int = 5_000,
    n_features:    int   = 20,
    random_state:  int   = 42,
) -> tuple[list[dict], np.ndarray, np.ndarray]:
    """
    Classic pathological non-IID FL benchmark.

    Each client has a strongly skewed class distribution drawn from
    Uniform(0.1, 0.9), plus client-specific Gaussian feature noise.

    Parameters
    ----------
    n_clients      : int
    n_samples_total: int   Total samples split evenly across clients.
    n_features     : int
    random_state   : int

    Returns
    -------
    client_data  : list of dicts
    X_test       : ndarray (500, n_features)  balanced global test set
    y_test       : ndarray (500,)

    Each client dict has keys:
        client_id, X_train, y_train, X_test, y_test,
        is_adversarial, class_imbalance, n_train.
    """
    rng = np.random.RandomState(random_state)

    X, y_multi = make_classification(
        n_samples=n_samples_total, n_features=n_features,
        n_informative=12, n_redundant=4, n_classes=5,
        n_clusters_per_class=1, random_state=random_state,
    )
    y = (y_multi >= 2).astype(float)   # binary collapse

    pos_idx = np.where(y == 1)[0]
    neg_idx = np.where(y == 0)[0]
    n_each  = n_samples_total // n_clients

    client_data: list[dict] = []
    for c in range(n_clients):
        frac_pos = float(rng.uniform(0.1, 0.9))
        n_pos    = max(1, int(n_each * frac_pos))
        n_neg    = n_each - n_pos

        ps = rng.choice(pos_idx, n_pos, replace=True)
        ns = rng.choice(neg_idx, n_neg, replace=True)
        X_c = np.vstack([X[ps], X[ns]]) + rng.randn(n_each, n_features) * 0.3
        y_c = np.hstack([np.ones(n_pos), np.zeros(n_neg)])

        perm = rng.permutation(len(X_c))
        X_c, y_c = X_c[perm], y_c[perm]
        split = int(len(X_c) * 0.8)

        client_data.append({
            "client_id":       c,
            "X_train":         X_c[:split],
            "y_train":         y_c[:split],
            "X_test":          X_c[split:],
            "y_test":          y_c[split:],
            "is_adversarial":  False,
            "class_imbalance": frac_pos,
            "n_train":         split,
        })

    # Balanced global test set
    n_t   = 250
    tp    = rng.choice(pos_idx, n_t, replace=True)
    tn    = rng.choice(neg_idx, n_t, replace=True)
    X_test = np.vstack([X[tp], X[tn]])
    y_test = np.hstack([np.ones(n_t), np.zeros(n_t)])

    return client_data, X_test, y_test
