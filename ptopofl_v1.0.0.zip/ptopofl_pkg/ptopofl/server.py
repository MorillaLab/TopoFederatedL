"""
ptopofl.server
==============
pTopoFL server: topology-guided clustering, intra-cluster
topology-weighted aggregation, and inter-cluster consensus blending.

Algorithm (one round)
---------------------
Round 0 only:
    1. Collect descriptors from all clients.
    2. Normalise feature vectors; compute pairwise L2 distance matrix D.
    3. Hierarchical agglomerative clustering on D → cluster labels C.

Every round:
    4. Compute trust weights via z-score anomaly detection on D.
    5. For each cluster Cⱼ:
           wₖ ∝ nₖ · exp(−‖φ̂ₖ − φ̂_Cⱼ‖) · tₖ
           θ_Cⱼ = Σₖ∈Cⱼ wₖ θₖ
    6. Inter-cluster blending:
           θ̄ = Σⱼ (|Cⱼ|/K) θ_Cⱼ
           θ*_Cⱼ = (1−α) θ_Cⱼ + α θ̄
    7. Push θ*_Cⱼ to each client in Cⱼ.
"""

from __future__ import annotations

import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics.pairwise import euclidean_distances

from ptopofl.client import pTopoFLClient


class pTopoFLServer:
    """
    pTopoFL federation server.

    Parameters
    ----------
    n_clusters      : int   Number of topology-guided client clusters (default 2).
    alpha_blend     : float Inter-cluster blending coefficient α ∈ [0, 1].
                          α=0 → fully personalised; α=1 → standard FedAvg.
    anomaly_threshold : float  Z-score above which a client's trust decays
                                (default 2.0).
    random_state    : int

    Examples
    --------
    >>> server = pTopoFLServer(n_clusters=2, alpha_blend=0.3)
    >>> descs  = [c.get_descriptor() for c in clients]
    >>> server.fit_clusters(descs)
    >>> for r in range(15):
    ...     for c in clients:
    ...         c.train_local(server.cluster_params(c.client_id))
    ...     server.aggregate(clients, round_num=r)
    """

    def __init__(
        self,
        n_clusters:        int   = 2,
        alpha_blend:       float = 0.3,
        anomaly_threshold: float = 2.0,
        random_state:      int   = 42,
    ) -> None:
        self.n_clusters        = n_clusters
        self.alpha_blend       = alpha_blend
        self.anomaly_threshold = anomaly_threshold
        self._clustered        = False
        self.cluster_labels_:  np.ndarray | None = None
        self._feat_norm:       np.ndarray | None = None
        self.cluster_models:   dict[int, dict]   = {}
        self.round_logs:       list[dict]         = []

    # ------------------------------------------------------------------
    # Clustering (called once, round 0)
    # ------------------------------------------------------------------

    def fit_clusters(self, descriptors: list[dict]) -> np.ndarray:
        """
        Cluster clients by topological similarity.

        Parameters
        ----------
        descriptors : list of dicts from ``client.get_descriptor()``

        Returns
        -------
        cluster_labels : ndarray (n_clients,)
        """
        feat = np.array([d["feature_vector"] for d in descriptors],
                        dtype=float)
        norms = np.linalg.norm(feat, axis=1, keepdims=True) + 1e-8
        self._feat_norm = feat / norms

        D = euclidean_distances(self._feat_norm)
        n = len(descriptors)
        k = min(self.n_clusters, n - 1)

        if k < 2:
            self.cluster_labels_ = np.zeros(n, dtype=int)
        else:
            self.cluster_labels_ = AgglomerativeClustering(
                n_clusters=k, metric="precomputed", linkage="average"
            ).fit_predict(D)

        self._clustered = True
        return self.cluster_labels_

    # ------------------------------------------------------------------
    # Trust weights (adversarial detection)
    # ------------------------------------------------------------------

    def _trust(self, descriptors: list[dict]) -> np.ndarray:
        """
        Compute per-client trust weights.

        A client whose mean topological distance to all others exceeds
        (μ + 1)·σ receives exponentially decayed trust.
        """
        n    = len(descriptors)
        feat = np.array([d["feature_vector"] for d in descriptors], dtype=float)
        norms = np.linalg.norm(feat, axis=1, keepdims=True) + 1e-8
        fn   = feat / norms
        D    = euclidean_distances(fn)
        mu_d = D.sum(1) / max(n - 1, 1)
        z    = (mu_d - mu_d.mean()) / (mu_d.std() + 1e-8)
        return np.clip(np.exp(-np.maximum(z - 1.0, 0.0)), 0.05, 1.0)

    # ------------------------------------------------------------------
    # Aggregation (called every round)
    # ------------------------------------------------------------------

    def aggregate(
        self,
        clients:   list[pTopoFLClient],
        round_num: int = 0,
    ) -> tuple[dict, dict]:
        """
        Run one aggregation round.

        Clients must have called ``train_local`` before this.

        Parameters
        ----------
        clients   : list of pTopoFLClient
        round_num : int   Current round index (informational).

        Returns
        -------
        cluster_models : dict  {cluster_id: {'coef', 'intercept'}}
        log            : dict  Diagnostics for the round.
        """
        descriptors = [c.get_descriptor() for c in clients]

        if not self._clustered:
            self.fit_clusters(descriptors)

        labels  = self.cluster_labels_
        trust   = self._trust(descriptors)
        n_clust = int(labels.max()) + 1
        new_cm: dict[int, dict] = {}

        for cid in range(n_clust):
            members = [i for i, l in enumerate(labels) if l == cid]
            if not members:
                continue

            # Topology-similarity weight within cluster
            fn_m     = self._feat_norm[members]          # type: ignore[index]
            centroid = fn_m.mean(0)
            topo_sim = np.exp(-np.linalg.norm(fn_m - centroid, axis=1))

            params = [clients[i].get_params() for i in members]
            valid  = [(j, p) for j, p in enumerate(params) if p is not None]
            if not valid:
                continue

            # Guard: all params must share the same shape
            shapes = {p["coef"].shape for _, p in valid}
            if len(shapes) > 1:
                coefs = [p["coef"] for _, p in valid]
                ints  = [p["intercept"] for _, p in valid]
                new_cm[cid] = {
                    "coef":      np.mean(coefs, axis=0),
                    "intercept": np.mean(ints,  axis=0),
                }
                continue

            ns  = np.array([p["n_samples"]          for _, p in valid], float)
            ts  = np.array([trust[members[j]]        for j, _ in valid])
            sim = np.array([topo_sim[j]              for j, _ in valid])
            w   = ns * sim * ts
            w  /= w.sum() + 1e-8

            new_cm[cid] = {
                "coef":      sum(w[j] * p["coef"]      for j, (_, p) in enumerate(valid)),
                "intercept": sum(w[j] * p["intercept"] for j, (_, p) in enumerate(valid)),
            }

        # Inter-cluster blending
        if new_cm:
            sizes = np.array(
                [sum(1 for l in labels if l == cid) for cid in new_cm], float
            )
            cw = sizes / (sizes.sum() + 1e-8)
            g_coef = sum(w * v["coef"]      for w, v in zip(cw, new_cm.values()))
            g_int  = sum(w * v["intercept"] for w, v in zip(cw, new_cm.values()))
            α = self.alpha_blend
            for cid in new_cm:
                new_cm[cid]["coef"]      = (1 - α) * new_cm[cid]["coef"]      + α * g_coef
                new_cm[cid]["intercept"] = (1 - α) * new_cm[cid]["intercept"] + α * g_int

        self.cluster_models = new_cm

        # Push updated model to each client
        for i, c in enumerate(clients):
            cid = int(labels[i])
            if cid in new_cm:
                c.set_params(new_cm[cid])

        log = {
            "round":          round_num,
            "cluster_labels": labels.tolist(),
            "trust_weights":  trust.tolist(),
            "n_clusters":     n_clust,
            "flagged":        [i for i, t in enumerate(trust) if t < 0.5],
        }
        self.round_logs.append(log)
        return new_cm, log

    def cluster_params(self, client_id: int) -> dict | None:
        """
        Return the cluster sub-global model for a given client.

        Convenience helper for the training loop.
        """
        if self.cluster_labels_ is None:
            return None
        cid = int(self.cluster_labels_[client_id])
        return self.cluster_models.get(cid)


# ---------------------------------------------------------------------------
# Convenience runner
# ---------------------------------------------------------------------------

def run_rounds(
    clients:   list[pTopoFLClient],
    server:    pTopoFLServer,
    n_rounds:  int  = 15,
    verbose:   bool = False,
) -> tuple[list[float], list[float]]:
    """
    Run ``n_rounds`` of pTopoFL and return per-round metrics.

    Handles the full loop: cluster initialisation on round 0,
    local training, server aggregation, and evaluation.

    Parameters
    ----------
    clients  : list of pTopoFLClient (with train/test data)
    server   : pTopoFLServer
    n_rounds : int
    verbose  : bool  Print per-round AUC if True.

    Returns
    -------
    accs : list of float  Mean accuracy per round.
    aucs : list of float  Mean AUC-ROC per round.

    Examples
    --------
    >>> from ptopofl import pTopoFLClient, pTopoFLServer, run_rounds
    >>> from ptopofl.data import make_healthcare_federated
    >>> data, _, _ = make_healthcare_federated(n_clients=8)
    >>> clients = [pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
    ...                          d["X_test"],  d["y_test"]) for d in data]
    >>> server  = pTopoFLServer(n_clusters=2, alpha_blend=0.3)
    >>> server.fit_clusters([c.get_descriptor() for c in clients])
    >>> accs, aucs = run_rounds(clients, server, n_rounds=15, verbose=True)
    """
    # Initialise clusters on round 0 if not already done
    if not server._clustered:
        server.fit_clusters([c.get_descriptor() for c in clients])

    accs: list[float] = []
    aucs: list[float] = []

    for r in range(n_rounds):
        # Local training with current cluster model
        for c in clients:
            c.train_local(cluster_params=server.cluster_params(c.client_id))

        # Server aggregation
        _, log = server.aggregate(clients, round_num=r)

        # Evaluate
        metrics = [c.evaluate() for c in clients
                   if c.X_test is not None and len(c.X_test) > 0]
        mean_acc = float(np.mean([m["accuracy"] for m in metrics])) if metrics else 0.0
        mean_auc = float(np.mean([m["auc"]      for m in metrics])) if metrics else 0.5
        accs.append(mean_acc)
        aucs.append(mean_auc)

        if verbose:
            flagged = log["flagged"]
            print(
                f"  Round {r + 1:2d}/{n_rounds} | "
                f"Acc={mean_acc:.3f} | AUC={mean_auc:.3f} | "
                f"Flagged={flagged}"
            )

    return accs, aucs
