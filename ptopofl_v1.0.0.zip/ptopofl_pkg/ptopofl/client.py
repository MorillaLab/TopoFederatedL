"""
ptopofl.client
==============
pTopoFL federated learning client.

Each client holds local private data, computes a topological descriptor
(the only information it ever sends to the server), trains locally with
topology-guided sample weights, and receives a cluster sub-global model
back from the server.

Privacy guarantee: ``get_descriptor()`` returns only topological shape
summaries — no raw features, no labels, no gradients.
"""

from __future__ import annotations

import numpy as np
from sklearn.linear_model  import LogisticRegression
from sklearn.metrics        import roc_auc_score, accuracy_score
from sklearn.preprocessing  import StandardScaler

from ptopofl.tda import compute_topological_descriptor


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30.0, 30.0)))


def _topo_weights(
    X:       np.ndarray,
    desc:    dict,
    lo:      float = 0.2,
    hi:      float = 5.0,
) -> np.ndarray:
    """
    Per-sample weights from distance to the data centroid, scaled by H0
    amplitude.  Samples near topological noise are down-weighted.
    """
    Xs    = (X - X.mean(0)) / (X.std(0) + 1e-8)
    dists = np.linalg.norm(Xs - Xs.mean(0), axis=1)
    scale = max(float(desc["h0_amplitude"]), 0.1)
    w     = np.exp(-dists / scale)
    w    /= w.mean() + 1e-8
    return np.clip(w, lo, hi)


class pTopoFLClient:
    """
    pTopoFL federated learning client.

    Parameters
    ----------
    client_id     : int   Unique identifier (used to seed RNG per client).
    X_train       : array (n, d)
    y_train       : array (n,)  Binary labels in {0, 1}.
    X_test        : array (m, d), optional
    y_test        : array (m,),  optional
    n_tda_sample  : int   Points subsampled for persistent homology (default 80).
    random_state  : int   Base seed; actual seed = random_state + client_id.

    Examples
    --------
    >>> from ptopofl import pTopoFLClient
    >>> client = pTopoFLClient(0, X_train, y_train, X_test, y_test)
    >>> desc = client.get_descriptor()          # send to server
    >>> client.train_local(cluster_params)      # train after server reply
    >>> metrics = client.evaluate()             # {'accuracy': ..., 'auc': ...}
    """

    def __init__(
        self,
        client_id:    int,
        X_train:      np.ndarray,
        y_train:      np.ndarray,
        X_test:       np.ndarray | None = None,
        y_test:       np.ndarray | None = None,
        n_tda_sample: int = 80,
        random_state: int = 42,
    ) -> None:
        self.client_id    = int(client_id)
        self.X_train      = np.asarray(X_train, dtype=float)
        self.y_train      = np.asarray(y_train, dtype=float)
        self.X_test       = (np.asarray(X_test,  dtype=float)
                             if X_test is not None else None)
        self.y_test       = (np.asarray(y_test,  dtype=float)
                             if y_test is not None else None)
        self.n_tda_sample = n_tda_sample
        self.rng          = np.random.RandomState(random_state + self.client_id)
        self.scaler       = StandardScaler().fit(self.X_train)
        self._desc:  dict | None = None
        self.coef_:  np.ndarray | None = None
        self.intercept_: np.ndarray | None = None
        self._round  = 0

    # ------------------------------------------------------------------
    # Descriptor (privacy-safe, sent to server)
    # ------------------------------------------------------------------

    def compute_tda(self) -> dict:
        """Compute (and cache) the topological descriptor from local data."""
        if self._desc is None:
            self._desc = compute_topological_descriptor(
                self.X_train,
                n_sample=self.n_tda_sample,
                random_state=int(self.rng.randint(0, 10_000)),
            )
        return self._desc

    def get_descriptor(self) -> dict:
        """
        Return the privacy-safe descriptor transmitted to the server.

        Contains only topological shape summaries:
        feature_vector, h0_entropy, h1_entropy, h0_amplitude, n_samples.
        No raw features, no labels, no gradients.
        """
        d = self.compute_tda()
        return {
            "client_id":      self.client_id,
            "feature_vector": d["feature_vector"].copy(),
            "h0_entropy":     float(d["h0_entropy"]),
            "h1_entropy":     float(d["h1_entropy"]),
            "h0_amplitude":   float(d["h0_amplitude"]),
            "n_samples":      len(self.X_train),
        }

    # ------------------------------------------------------------------
    # Local training
    # ------------------------------------------------------------------

    def train_local(
        self,
        cluster_params: dict | None = None,
    ) -> "pTopoFLClient":
        """
        Train local logistic regression with topology-guided sample weights.

        Parameters
        ----------
        cluster_params : dict with keys 'coef' and 'intercept', or None.
            The cluster sub-global model provided by the server.
            Used as warm-start; falls back to cold-start if None or
            incompatible shape.
        """
        X  = self.scaler.transform(self.X_train)
        y  = self.y_train
        sw = _topo_weights(self.X_train, self.compute_tda())

        lr = LogisticRegression(
            max_iter=300, C=1.0, solver="lbfgs",
            random_state=int(self.rng.randint(0, 100_000)),
        )
        if cluster_params is not None:
            try:
                lr.coef_      = cluster_params["coef"].copy()
                lr.intercept_ = cluster_params["intercept"].copy()
                lr.classes_   = np.array([0.0, 1.0])
                lr.warm_start = True
            except Exception:
                pass

        lr.fit(X, y, sample_weight=sw)
        self.coef_      = lr.coef_
        self.intercept_ = lr.intercept_
        self._round    += 1
        return self

    # ------------------------------------------------------------------
    # Parameter exchange with server
    # ------------------------------------------------------------------

    def get_params(self) -> dict | None:
        """Return model parameters for server aggregation.  None if untrained."""
        if self.coef_ is None:
            return None
        return {
            "coef":      self.coef_.copy(),
            "intercept": self.intercept_.copy(),
            "n_samples": len(self.X_train),
        }

    def set_params(self, params: dict) -> None:
        """Receive aggregated cluster model from the server."""
        self.coef_      = np.array(params["coef"])
        self.intercept_ = np.array(params["intercept"])

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(self) -> dict:
        """
        Evaluate on local test set.

        Returns
        -------
        dict
            accuracy : float
            auc      : float (0.5 if untrained or no test data)
        """
        if (self.coef_ is None
                or self.X_test is None
                or len(self.X_test) == 0):
            return {"accuracy": 0.0, "auc": 0.5}

        Xt     = self.scaler.transform(self.X_test)
        logits = Xt @ self.coef_.T + self.intercept_
        probs  = _sigmoid(logits[:, 0])
        preds  = (probs >= 0.5).astype(int)
        try:
            auc = float(roc_auc_score(self.y_test, probs))
        except ValueError:
            auc = 0.5
        return {
            "accuracy": float(accuracy_score(self.y_test, preds)),
            "auc":      auc,
        }

    def __repr__(self) -> str:
        status = "trained" if self.coef_ is not None else "untrained"
        return (
            f"pTopoFLClient(id={self.client_id}, "
            f"n_train={len(self.X_train)}, {status}, round={self._round})"
        )
