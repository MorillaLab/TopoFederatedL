"""
pTopoFL — Personalised Topology-Aware Federated Learning
=========================================================
Privacy-preserving federated learning via persistent homology.

Clients transmit compact topological descriptors instead of gradients.
The server performs topology-guided clustering, intra-cluster
topology-weighted aggregation, and inter-cluster consensus blending.

Quick start
-----------
>>> from ptopofl import pTopoFLClient, pTopoFLServer, run_rounds
>>> from ptopofl.data import make_healthcare_federated
>>>
>>> data, _, _ = make_healthcare_federated(n_clients=8, random_state=42)
>>> clients = [
...     pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
...                   d["X_test"],   d["y_test"])
...     for d in data
... ]
>>> server = pTopoFLServer(n_clusters=2, alpha_blend=0.3)
>>> server.fit_clusters([c.get_descriptor() for c in clients])
>>> accs, aucs = run_rounds(clients, server, n_rounds=15, verbose=True)
>>> print(f"Final AUC: {aucs[-1]:.3f}")

Citation
--------
If you use pTopoFL in your research, please cite:

    Morilla, I. & Ginot, G. (2025).
    pTopoFL: Privacy-Preserving Personalised Federated Learning
    via Persistent Homology. arXiv preprint.
    https://github.com/MorillaLab/TopoFederatedL
"""

__version__ = "1.0.0"
__author__  = "Ian Morilla, Grégory Ginot"
__email__   = "morilla@math.univ-paris13.fr"
__license__ = "GPL-3.0"

from ptopofl.client import pTopoFLClient
from ptopofl.server import pTopoFLServer, run_rounds
from ptopofl.tda    import (
    compute_topological_descriptor,
    descriptor_distance,
    wasserstein_distance_diagrams,
    persistence_entropy,
    diagram_amplitude,
    betti_curve,
)

__all__ = [
    # Core FL
    "pTopoFLClient",
    "pTopoFLServer",
    "run_rounds",
    # TDA primitives
    "compute_topological_descriptor",
    "descriptor_distance",
    "wasserstein_distance_diagrams",
    "persistence_entropy",
    "diagram_amplitude",
    "betti_curve",
]
