"""
ptopofl.tda
===========
Topological Data Analysis core — persistent homology from scratch.

All computation uses only NumPy and SciPy.  No external TDA library
(GUDHI, Ripser, Giotto-TDA) is required.

Public API
----------
compute_topological_descriptor(X, n_sample, n_thresholds, random_state)
    Compute a 48-dimensional privacy-safe descriptor for a client dataset.

descriptor_distance(desc_a, desc_b)
    L2 distance between two normalised feature vectors.

wasserstein_distance_diagrams(dgm1, dgm2, p)
    Approximate W_p distance between two persistence diagrams.

persistence_entropy(pairs)
diagram_amplitude(pairs, p)
betti_curve(pairs, thresholds)

Theory
------
H0 (connected components): computed exactly via union-find on the
Vietoris-Rips filtration (Kruskal's algorithm).

H1 (1-cycles): approximated via the triangle filtration — for each
triple of points, a cycle is born at the second-longest edge and dies
when the triangle is filled.  This approximation is sufficient for the
clustering and privacy applications in pTopoFL.

Privacy property
----------------
The map  D_k  →  φ_k  is many-to-one: infinitely many datasets share
the same topological descriptor, making inversion provably ill-posed.
See Theorem 1 (Information Contraction) in the paper.

References
----------
Edelsbrunner, H., Letscher, D., & Zomorodian, A. (2002).
    Topological persistence and simplification.
    Discrete & Computational Geometry, 28(4), 511–533.

Cohen-Steiner, D., Edelsbrunner, H., & Harer, J. (2007).
    Stability of persistence diagrams.
    Discrete & Computational Geometry, 37(1), 103–120.
"""

from __future__ import annotations

import numpy as np
from itertools import combinations
from scipy.spatial.distance import cdist


# ---------------------------------------------------------------------------
# Internal: Union-Find for H0
# ---------------------------------------------------------------------------

class _UF:
    """Path-compressed, rank-union disjoint-set structure."""

    __slots__ = ("parent", "rank")

    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.rank   = [0] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]   # path halving
            x = self.parent[x]
        return x

    def union(self, x: int, y: int) -> bool:
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return False
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1
        return True


# ---------------------------------------------------------------------------
# H0: connected components via Kruskal
# ---------------------------------------------------------------------------

def _h0(D: np.ndarray) -> list[tuple[float, float]]:
    """
    Exact H0 persistence diagram via Kruskal's algorithm.

    Returns list of (birth=0, death) pairs.
    The essential class (last survivor) has death = np.inf.
    """
    n = D.shape[0]
    edges = sorted(
        ((D[i, j], i, j) for i in range(n) for j in range(i + 1, n)),
        key=lambda e: e[0],
    )
    uf     = _UF(n)
    alive  = n
    pairs: list[tuple[float, float]] = []

    for w, i, j in edges:
        if uf.union(i, j):
            pairs.append((0.0, float(w)))
            alive -= 1
            if alive == 1:
                break

    pairs.append((0.0, np.inf))   # essential class
    return pairs


# ---------------------------------------------------------------------------
# H1: 1-cycles via triangle filtration
# ---------------------------------------------------------------------------

def _h1(
    pts: np.ndarray,
    edge_quantile: float = 0.75,
    max_features:  int   = 25,
) -> list[tuple[float, float]]:
    """
    Approximate H1 persistence via the Vietoris-Rips triangle filtration.

    For each triple (i,j,k), the 1-cycle is born at the second-longest
    edge and dies when the triangle fills it (longest edge).

    Parameters
    ----------
    edge_quantile : only consider edges below this distance quantile.
    max_features  : cap on returned pairs (avoids O(n³) memory blow-up).
    """
    n = len(pts)
    if n < 3:
        return []

    D   = cdist(pts, pts)
    thr = float(np.percentile(D[D > 0], edge_quantile * 100))
    pairs: list[tuple[float, float]] = []

    for i, j, k in combinations(range(n), 3):
        e1, e2, e3 = sorted([D[i, j], D[i, k], D[j, k]])
        if e2 < thr and (e3 - e2) > 1e-8:
            pairs.append((float(e2), float(e3)))

    if not pairs:
        return pairs
    pairs.sort(key=lambda p: p[1] - p[0], reverse=True)
    return pairs[:max_features]


# ---------------------------------------------------------------------------
# Diagram utilities
# ---------------------------------------------------------------------------

def _finite(pairs: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """Filter out essential (infinite-death) pairs."""
    return [(b, d) for b, d in pairs if np.isfinite(d)]


def _pers(pairs: list[tuple[float, float]]) -> list[float]:
    """Persistence values (death − birth) for finite pairs."""
    return [d - b for b, d in _finite(pairs)]


def persistence_entropy(pairs: list[tuple[float, float]]) -> float:
    """
    Persistence entropy: H = −Σ pᵢ log pᵢ,  pᵢ = persᵢ / Σ persⱼ.

    Returns 0.0 for empty or zero-persistence diagrams.
    """
    ps = _pers(pairs)
    if not ps or sum(ps) == 0.0:
        return 0.0
    tot   = sum(ps)
    probs = [p / tot for p in ps]
    return float(-sum(p * np.log(p + 1e-12) for p in probs))


def diagram_amplitude(pairs: list[tuple[float, float]], p: int = 2) -> float:
    """L^p amplitude: (Σ persᵢᵖ)^(1/p).  Returns 0.0 for empty diagrams."""
    ps = _pers(pairs)
    if not ps:
        return 0.0
    return float(np.sum(np.array(ps) ** p) ** (1.0 / p))


def betti_curve(
    pairs:      list[tuple[float, float]],
    thresholds: np.ndarray,
) -> np.ndarray:
    """Number of alive features at each filtration threshold."""
    fp    = _finite(pairs)
    curve = np.zeros(len(thresholds))
    for idx, t in enumerate(thresholds):
        curve[idx] = sum(1 for b, d in fp if b <= t < d)
    return curve


# ---------------------------------------------------------------------------
# Wasserstein distance between diagrams
# ---------------------------------------------------------------------------

def wasserstein_distance_diagrams(
    dgm1: list[tuple[float, float]],
    dgm2: list[tuple[float, float]],
    p:    int = 2,
) -> float:
    """
    Approximate W_p distance between two persistence diagrams.

    Uses greedy matching with diagonal projections.
    Exact for small diagrams (≤ ~20 points); sufficient for FL descriptor
    comparison.

    Parameters
    ----------
    dgm1, dgm2 : lists of (birth, death) pairs
    p          : Wasserstein exponent (default 2)
    """
    pts1 = np.array(_finite(dgm1)) if dgm1 else np.empty((0, 2))
    pts2 = np.array(_finite(dgm2)) if dgm2 else np.empty((0, 2))

    if len(pts1) == 0 and len(pts2) == 0:
        return 0.0

    def _proj(pts: np.ndarray) -> np.ndarray:
        if len(pts) == 0:
            return np.empty((0, 2))
        mid = (pts[:, 0] + pts[:, 1]) / 2.0
        return np.column_stack([mid, mid])

    aug1 = np.vstack([pts1, _proj(pts2)]) if len(pts2) > 0 else pts1
    aug2 = np.vstack([pts2, _proj(pts1)]) if len(pts1) > 0 else pts2

    if len(aug1) == 0 or len(aug2) == 0:
        return 0.0

    cost  = cdist(aug1, aug2) ** p
    used  = set()
    total = 0.0
    for i in range(len(aug1)):
        avail = [j for j in range(len(aug2)) if j not in used]
        if not avail:
            break
        j_best = min(avail, key=lambda j: cost[i, j])
        total += cost[i, j_best]
        used.add(j_best)

    return float(total ** (1.0 / p))


# ---------------------------------------------------------------------------
# Full topological descriptor
# ---------------------------------------------------------------------------

def compute_topological_descriptor(
    X:            np.ndarray,
    n_sample:     int = 80,
    n_thresholds: int = 20,
    random_state: int = 42,
) -> dict:
    """
    Compute a 48-dimensional privacy-safe topological descriptor for a
    client dataset.

    The descriptor encodes the *shape* of the data distribution, not
    individual records.  The map X → φ is many-to-one: infinitely many
    datasets share the same descriptor, making reconstruction
    provably ill-posed (Theorem 1 in the paper).

    Parameters
    ----------
    X            : array-like, shape (n_samples, n_features)
    n_sample     : max points subsampled for PH computation (default 80)
    n_thresholds : Betti-curve resolution (default 20)
    random_state : reproducibility seed

    Returns
    -------
    dict
        feature_vector  ndarray (2*n_thresholds + 8,)  ← used for clustering
        h0_pairs        list of (birth, death)           ← H0 diagram
        h1_pairs        list of (birth, death)           ← H1 diagram
        h0_entropy      float
        h1_entropy      float
        h0_amplitude    float
        h1_amplitude    float
        betti0_curve    ndarray (n_thresholds,)
        betti1_curve    ndarray (n_thresholds,)
        thresholds      ndarray (n_thresholds,)
        n_persistent_h0 int — H0 features above median persistence
        n_persistent_h1 int
    """
    X   = np.asarray(X, dtype=float)
    rng = np.random.RandomState(random_state)

    # Subsample for efficiency
    n = len(X)
    if n > n_sample:
        idx = rng.choice(n, n_sample, replace=False)
        Xs  = X[idx]
    else:
        Xs = X.copy()

    # Standardise
    mu, sd = Xs.mean(0), Xs.std(0) + 1e-8
    Xs = (Xs - mu) / sd

    # Compute diagrams
    D  = cdist(Xs, Xs)
    h0 = _h0(D)
    h1 = _h1(Xs)

    # Threshold grid for Betti curves
    deaths = [d for _, d in _finite(h0)] + [d for _, d in _finite(h1)]
    t_max  = float(np.percentile(deaths, 95)) if deaths else float(D.max())
    thresholds = np.linspace(0.0, t_max, n_thresholds)

    bc0 = betti_curve(h0, thresholds)
    bc1 = betti_curve(h1, thresholds)

    h0_ent, h1_ent = persistence_entropy(h0), persistence_entropy(h1)
    h0_amp, h1_amp = diagram_amplitude(h0),   diagram_amplitude(h1)

    h0p, h1p = _pers(h0), _pers(h1)
    med0, med1 = (float(np.median(h0p)) if h0p else 0.0,
                  float(np.median(h1p)) if h1p else 0.0)
    n_ph0 = int(sum(p > med0 for p in h0p))
    n_ph1 = int(sum(p > med1 for p in h1p))

    feature_vector = np.concatenate([
        bc0, bc1,
        [h0_ent, h1_ent, h0_amp, h1_amp,
         float(n_ph0), float(n_ph1),
         float(len(_finite(h0))), float(len(h1))],
    ])

    return {
        "feature_vector":   feature_vector,
        "h0_pairs":         h0,
        "h1_pairs":         h1,
        "h0_entropy":       h0_ent,
        "h1_entropy":       h1_ent,
        "h0_amplitude":     h0_amp,
        "h1_amplitude":     h1_amp,
        "betti0_curve":     bc0,
        "betti1_curve":     bc1,
        "thresholds":       thresholds,
        "n_persistent_h0":  n_ph0,
        "n_persistent_h1":  n_ph1,
    }


def descriptor_distance(desc_a: dict, desc_b: dict) -> float:
    """
    Normalised L2 distance between two topological feature vectors.

    Returns a value in [0, 2].
    """
    fa   = desc_a["feature_vector"]
    fb   = desc_b["feature_vector"]
    norm = np.linalg.norm(fa) + np.linalg.norm(fb) + 1e-8
    return float(np.linalg.norm(fa - fb) / norm * 2.0)
