"""
ptopofl.baselines
=================
Federated learning baselines implemented from scratch with NumPy/scikit-learn.

Classes
-------
FedAvgClient  / FedAvgServer
FedProxClient / FedProxServer    (Li et al. 2020, MLSys)
SCAFFOLDClient / SCAFFOLDServer  (Karimireddy et al. 2020, ICML)
pFedMeClient  / pFedMeServer     (T Dinh et al. 2020, NeurIPS)

run_baseline_rounds(clients, server, n_rounds, verbose)
    Generic runner compatible with all four baselines.

All baselines use the same logistic-regression local model as pTopoFL,
isolating the federation mechanism rather than model capacity.
"""

from __future__ import annotations

import numpy as np
from sklearn.linear_model  import LogisticRegression
from sklearn.metrics        import accuracy_score, roc_auc_score
from sklearn.preprocessing  import StandardScaler


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30.0, 30.0)))


def _lr_grad(
    X: np.ndarray, y: np.ndarray,
    coef: np.ndarray, intercept: np.ndarray,
    C: float = 1.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Logistic regression gradient with L2 regularisation."""
    n      = len(y)
    probs  = _sigmoid((X @ coef.T + intercept)[:, 0])
    err    = probs - y
    g_coef = (X.T @ err) / n + coef / (C * n)
    g_int  = np.array([err.mean()])
    return g_coef.reshape(coef.shape), g_int


def _evaluate(
    X: np.ndarray, y: np.ndarray,
    coef: np.ndarray, intercept: np.ndarray,
    scaler: StandardScaler,
) -> dict:
    Xs     = scaler.transform(X)
    logits = (Xs @ coef.T + intercept)
    probs  = _sigmoid(logits[:, 0])
    preds  = (probs >= 0.5).astype(int)
    try:
        auc = float(roc_auc_score(y, probs))
    except ValueError:
        auc = 0.5
    return {"accuracy": float(accuracy_score(y, preds)), "auc": auc}


# ---------------------------------------------------------------------------
# FedAvg
# ---------------------------------------------------------------------------

class FedAvgClient:
    """Standard FedAvg client (McMahan et al. 2017)."""

    def __init__(
        self,
        client_id: int,
        X_train: np.ndarray, y_train: np.ndarray,
        X_test:  np.ndarray | None = None,
        y_test:  np.ndarray | None = None,
        random_state: int = 42,
    ) -> None:
        self.client_id = client_id
        self.X_train   = np.asarray(X_train, dtype=float)
        self.y_train   = np.asarray(y_train, dtype=float)
        self.X_test    = np.asarray(X_test,  dtype=float) if X_test is not None else None
        self.y_test    = np.asarray(y_test,  dtype=float) if y_test is not None else None
        self.scaler    = StandardScaler().fit(self.X_train)
        self.coef_     = None
        self.intercept_= None
        self.rng       = np.random.RandomState(random_state + client_id)

    def train_local(self, global_params: dict | None = None, **_) -> "FedAvgClient":
        lr = LogisticRegression(max_iter=300, C=1.0, solver="lbfgs",
                                random_state=int(self.rng.randint(0, 100_000)))
        if global_params is not None:
            try:
                lr.coef_      = global_params["coef"].copy()
                lr.intercept_ = global_params["intercept"].copy()
                lr.classes_   = np.array([0.0, 1.0])
                lr.warm_start = True
            except Exception:
                pass
        lr.fit(self.scaler.transform(self.X_train), self.y_train)
        self.coef_, self.intercept_ = lr.coef_, lr.intercept_
        return self

    def get_params(self) -> dict | None:
        if self.coef_ is None:
            return None
        return {"coef": self.coef_.copy(), "intercept": self.intercept_.copy(),
                "n_samples": len(self.X_train)}

    def set_global_params(self, params: dict) -> None:
        if params:
            self.coef_, self.intercept_ = (params["coef"].copy(),
                                           params["intercept"].copy())

    def evaluate(self) -> dict:
        if self.coef_ is None or self.X_test is None:
            return {"accuracy": 0.0, "auc": 0.5}
        return _evaluate(self.X_test, self.y_test,
                         self.coef_, self.intercept_, self.scaler)


class FedAvgServer:
    """Standard FedAvg server."""

    def __init__(self) -> None:
        self.global_params: dict | None = None

    def aggregate(self, clients, round_num: int = 0) -> tuple:
        params = [c.get_params() for c in clients]
        valid  = [p for p in params if p is not None]
        if not valid:
            return self.global_params, {}
        if len({p["coef"].shape for p in valid}) > 1:
            self.global_params = valid[0]; return self.global_params, {}
        n_tot = sum(p["n_samples"] for p in valid)
        self.global_params = {
            "coef":      sum(p["n_samples"] / n_tot * p["coef"]      for p in valid),
            "intercept": sum(p["n_samples"] / n_tot * p["intercept"] for p in valid),
        }
        return self.global_params, {}


# ---------------------------------------------------------------------------
# FedProx  (Li et al. 2020)
# ---------------------------------------------------------------------------

class FedProxClient:
    """
    FedProx: adds proximal term μ/2 ‖θ − θ_global‖² to the local objective.

    Reference: Li et al. (2020). Federated optimization in heterogeneous
    networks. MLSys.
    """

    def __init__(
        self,
        client_id: int,
        X_train: np.ndarray, y_train: np.ndarray,
        X_test:  np.ndarray | None = None,
        y_test:  np.ndarray | None = None,
        mu: float = 0.1, lr: float = 0.05, n_steps: int = 30,
        random_state: int = 42,
    ) -> None:
        self.client_id  = client_id
        self.X_train    = np.asarray(X_train, dtype=float)
        self.y_train    = np.asarray(y_train, dtype=float)
        self.X_test     = np.asarray(X_test,  dtype=float) if X_test is not None else None
        self.y_test     = np.asarray(y_test,  dtype=float) if y_test is not None else None
        self.mu, self.lr, self.n_steps = mu, lr, n_steps
        self.scaler     = StandardScaler()
        self.coef_      = None
        self.intercept_ = None
        self.rng        = np.random.RandomState(random_state + client_id)

    def train_local(self, global_params: dict | None = None, **_) -> "FedProxClient":
        X = self.scaler.fit_transform(self.X_train)
        d = X.shape[1]
        if self.coef_ is None:
            self.coef_      = self.rng.randn(1, d) * 0.01
            self.intercept_ = np.zeros(1)
        coef_g = global_params["coef"].copy() if global_params else self.coef_.copy()
        int_g  = global_params["intercept"].copy() if global_params else self.intercept_.copy()
        coef, intercept = self.coef_.copy(), self.intercept_.copy()
        for _ in range(self.n_steps):
            gc, gi = _lr_grad(X, self.y_train, coef, intercept)
            coef      -= self.lr * (gc + self.mu * (coef      - coef_g))
            intercept -= self.lr * (gi + self.mu * (intercept - int_g))
        self.coef_, self.intercept_ = coef, intercept
        return self

    def get_params(self) -> dict | None:
        if self.coef_ is None: return None
        return {"coef": self.coef_.copy(), "intercept": self.intercept_.copy(),
                "n_samples": len(self.X_train)}

    def set_global_params(self, params: dict) -> None:
        if params:
            self.coef_, self.intercept_ = (params["coef"].copy(),
                                           params["intercept"].copy())

    def evaluate(self) -> dict:
        if self.coef_ is None or self.X_test is None:
            return {"accuracy": 0.0, "auc": 0.5}
        return _evaluate(self.X_test, self.y_test,
                         self.coef_, self.intercept_, self.scaler)


class FedProxServer:
    """FedProx server (same aggregation as FedAvg)."""
    def __init__(self) -> None:
        self.global_params: dict | None = None

    def aggregate(self, clients, round_num: int = 0) -> tuple:
        params = [c.get_params() for c in clients]
        valid  = [p for p in params if p is not None]
        if not valid: return self.global_params, {}
        if len({p["coef"].shape for p in valid}) > 1:
            self.global_params = valid[0]; return self.global_params, {}
        n_tot = sum(p["n_samples"] for p in valid)
        self.global_params = {
            "coef":      sum(p["n_samples"] / n_tot * p["coef"]      for p in valid),
            "intercept": sum(p["n_samples"] / n_tot * p["intercept"] for p in valid),
        }
        return self.global_params, {}


# ---------------------------------------------------------------------------
# SCAFFOLD  (Karimireddy et al. 2020)
# ---------------------------------------------------------------------------

class SCAFFOLDClient:
    """
    SCAFFOLD: control-variate correction for client drift.

    Update rule:
        y_k ← θ − η (∇F_k − c_k + c)
        Δc_k ← (θ_old − y_k) / (K·η) − c

    Reference: Karimireddy et al. (2020). SCAFFOLD: Stochastic controlled
    averaging for federated learning. ICML.
    """

    def __init__(
        self,
        client_id: int,
        X_train: np.ndarray, y_train: np.ndarray,
        X_test:  np.ndarray | None = None,
        y_test:  np.ndarray | None = None,
        lr: float = 0.05, n_steps: int = 30,
        random_state: int = 42,
    ) -> None:
        self.client_id  = client_id
        self.X_train    = np.asarray(X_train, dtype=float)
        self.y_train    = np.asarray(y_train, dtype=float)
        self.X_test     = np.asarray(X_test,  dtype=float) if X_test is not None else None
        self.y_test     = np.asarray(y_test,  dtype=float) if y_test is not None else None
        self.lr, self.n_steps = lr, n_steps
        self.scaler     = StandardScaler()
        self.coef_      = None
        self.intercept_ = None
        self.c_coef_    = None   # client control variate
        self.c_int_     = None
        self.rng        = np.random.RandomState(random_state + client_id)

    def train_local(
        self,
        global_params:   dict | None = None,
        global_control:  dict | None = None,
        **_,
    ) -> "SCAFFOLDClient":
        X = self.scaler.fit_transform(self.X_train)
        d = X.shape[1]
        if self.coef_ is None:
            self.coef_   = self.rng.randn(1, d) * 0.01
            self.intercept_ = np.zeros(1)
            self.c_coef_ = np.zeros((1, d))
            self.c_int_  = np.zeros(1)

        coef = global_params["coef"].copy() if global_params else self.coef_.copy()
        intercept = global_params["intercept"].copy() if global_params else self.intercept_.copy()
        c_coef = global_control["coef"] if global_control else np.zeros_like(coef)
        c_int  = global_control["intercept"] if global_control else np.zeros_like(intercept)

        old_coef, old_int = coef.copy(), intercept.copy()
        for _ in range(self.n_steps):
            gc, gi = _lr_grad(X, self.y_train, coef, intercept)
            coef      -= self.lr * (gc - self.c_coef_ + c_coef)
            intercept -= self.lr * (gi - self.c_int_  + c_int)

        delta_c_coef = (old_coef - coef) / (self.n_steps * self.lr) - c_coef
        delta_c_int  = (old_int  - intercept) / (self.n_steps * self.lr) - c_int
        self.c_coef_ += delta_c_coef
        self.c_int_  += delta_c_int
        self.coef_, self.intercept_ = coef, intercept
        return self

    def get_params(self) -> dict | None:
        if self.coef_ is None: return None
        return {"coef": self.coef_.copy(), "intercept": self.intercept_.copy(),
                "n_samples": len(self.X_train),
                "delta_c_coef": self.c_coef_.copy(),
                "delta_c_int":  self.c_int_.copy()}

    def set_global_params(self, params: dict) -> None:
        if params:
            self.coef_, self.intercept_ = (params["coef"].copy(),
                                           params["intercept"].copy())

    def evaluate(self) -> dict:
        if self.coef_ is None or self.X_test is None:
            return {"accuracy": 0.0, "auc": 0.5}
        return _evaluate(self.X_test, self.y_test,
                         self.coef_, self.intercept_, self.scaler)


class SCAFFOLDServer:
    """SCAFFOLD server with global control-variate update."""

    def __init__(self) -> None:
        self.global_params:  dict | None = None
        self.global_control: dict | None = None

    def aggregate(self, clients, round_num: int = 0) -> tuple:
        params = [c.get_params() for c in clients]
        valid  = [p for p in params if p is not None]
        if not valid: return self.global_params, {}
        if len({p["coef"].shape for p in valid}) > 1:
            self.global_params = valid[0]; return self.global_params, {}
        n_tot = sum(p["n_samples"] for p in valid)
        agg_c = sum(p["n_samples"] / n_tot * p["coef"]      for p in valid)
        agg_i = sum(p["n_samples"] / n_tot * p["intercept"] for p in valid)
        K = len(valid)
        if self.global_control is None:
            self.global_control = {"coef": np.zeros_like(agg_c),
                                   "intercept": np.zeros_like(agg_i)}
        self.global_control["coef"]      += sum(p["delta_c_coef"] for p in valid) / K
        self.global_control["intercept"] += sum(p["delta_c_int"]  for p in valid) / K
        self.global_params = {"coef": agg_c, "intercept": agg_i}
        return self.global_params, {}


# ---------------------------------------------------------------------------
# pFedMe  (T Dinh et al. 2020)
# ---------------------------------------------------------------------------

class pFedMeClient:
    """
    pFedMe: personalisation via Moreau envelopes.

    Each client minimises:
        F_k(θ_k) + λ/2 · ‖θ_k − w‖²
    Inner loop: optimise personalised θ_k given global w.
    Outer update: w ← w − η·λ·(w − θ_k)

    Reference: T Dinh, C., Tran, N., & Nguyen, T. (2020). Personalized
    federated learning with Moreau envelopes. NeurIPS.
    """

    def __init__(
        self,
        client_id: int,
        X_train: np.ndarray, y_train: np.ndarray,
        X_test:  np.ndarray | None = None,
        y_test:  np.ndarray | None = None,
        lam: float = 15.0, lr: float = 0.01,
        lr_personal: float = 0.01, n_steps: int = 20,
        random_state: int = 42,
    ) -> None:
        self.client_id   = client_id
        self.X_train     = np.asarray(X_train, dtype=float)
        self.y_train     = np.asarray(y_train, dtype=float)
        self.X_test      = np.asarray(X_test,  dtype=float) if X_test is not None else None
        self.y_test      = np.asarray(y_test,  dtype=float) if y_test is not None else None
        self.lam, self.lr, self.lr_p, self.n_steps = lam, lr, lr_personal, n_steps
        self.scaler      = StandardScaler()
        self.coef_       = None   # personalised θ_k
        self.intercept_  = None
        self.w_coef_     = None   # global w (local copy)
        self.w_int_      = None
        self.rng         = np.random.RandomState(random_state + client_id)

    def train_local(self, global_params: dict | None = None, **_) -> "pFedMeClient":
        X = self.scaler.fit_transform(self.X_train)
        d = X.shape[1]
        if self.coef_ is None:
            self.coef_   = self.rng.randn(1, d) * 0.01
            self.intercept_ = np.zeros(1)
            self.w_coef_ = self.coef_.copy()
            self.w_int_  = self.intercept_.copy()
        if global_params:
            self.w_coef_ = global_params["coef"].copy()
            self.w_int_  = global_params["intercept"].copy()

        coef, intercept = self.coef_.copy(), self.intercept_.copy()
        for _ in range(self.n_steps):
            gc, gi = _lr_grad(X, self.y_train, coef, intercept)
            coef      -= self.lr_p * (gc + self.lam * (coef      - self.w_coef_))
            intercept -= self.lr_p * (gi + self.lam * (intercept - self.w_int_))
        self.coef_, self.intercept_ = coef, intercept
        self.w_coef_ -= self.lr * self.lam * (self.w_coef_ - coef)
        self.w_int_  -= self.lr * self.lam * (self.w_int_  - intercept)
        return self

    def get_params(self) -> dict | None:
        if self.w_coef_ is None: return None
        return {"coef": self.w_coef_.copy(), "intercept": self.w_int_.copy(),
                "n_samples": len(self.X_train)}

    def set_global_params(self, params: dict) -> None:
        if params:
            self.w_coef_, self.w_int_ = (params["coef"].copy(),
                                         params["intercept"].copy())

    def evaluate(self) -> dict:
        if self.coef_ is None or self.X_test is None:
            return {"accuracy": 0.0, "auc": 0.5}
        return _evaluate(self.X_test, self.y_test,
                         self.coef_, self.intercept_, self.scaler)


class pFedMeServer:
    """pFedMe server (standard FedAvg aggregation on global w)."""
    def __init__(self) -> None:
        self.global_params: dict | None = None

    def aggregate(self, clients, round_num: int = 0) -> tuple:
        params = [c.get_params() for c in clients]
        valid  = [p for p in params if p is not None]
        if not valid: return self.global_params, {}
        n_tot = sum(p["n_samples"] for p in valid)
        self.global_params = {
            "coef":      sum(p["n_samples"] / n_tot * p["coef"]      for p in valid),
            "intercept": sum(p["n_samples"] / n_tot * p["intercept"] for p in valid),
        }
        return self.global_params, {}


# ---------------------------------------------------------------------------
# Generic runner for all baselines
# ---------------------------------------------------------------------------

def run_baseline_rounds(
    clients,
    server,
    n_rounds: int  = 15,
    verbose:  bool = False,
) -> tuple[list[float], list[float]]:
    """
    Generic training loop compatible with all four baselines.

    Parameters
    ----------
    clients  : list of client objects (FedAvg / FedProx / SCAFFOLD / pFedMe)
    server   : matching server object
    n_rounds : int
    verbose  : bool

    Returns
    -------
    accs : list[float]
    aucs : list[float]
    """
    accs: list[float] = []
    aucs: list[float] = []

    for r in range(n_rounds):
        gp = getattr(server, "global_params", None)
        gc = getattr(server, "global_control", None)
        for c in clients:
            if gc is not None:
                c.train_local(global_params=gp, global_control=gc)
            else:
                c.train_local(global_params=gp)

        server.aggregate(clients, round_num=r)

        for c in clients:
            if hasattr(c, "set_global_params"):
                c.set_global_params(server.global_params)

        metrics = [c.evaluate() for c in clients
                   if c.X_test is not None and len(c.X_test) > 0]
        mean_acc = float(np.mean([m["accuracy"] for m in metrics])) if metrics else 0.0
        mean_auc = float(np.mean([m["auc"]      for m in metrics])) if metrics else 0.5
        accs.append(mean_acc)
        aucs.append(mean_auc)

        if verbose:
            name = type(server).__name__
            print(f"  [{name}] Round {r + 1:2d}/{n_rounds} | "
                  f"Acc={mean_acc:.3f} | AUC={mean_auc:.3f}")

    return accs, aucs
