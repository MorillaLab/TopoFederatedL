"""
examples/quickstart.py
======================
Minimal working example of pTopoFL.

Run:
    python examples/quickstart.py
"""

from ptopofl import pTopoFLClient, pTopoFLServer, run_rounds
from ptopofl.data import make_healthcare_federated

# 1. Generate non-IID healthcare data (8 hospitals, 2 adversarial)
client_data, X_test, y_test = make_healthcare_federated(
    n_clients=8,
    adversarial_clients=[1, 5],
    random_state=42,
)

# 2. Create clients — each holds only local private data
clients = [
    pTopoFLClient(
        d["client_id"],
        d["X_train"], d["y_train"],
        d["X_test"],  d["y_test"],
    )
    for d in client_data
]

# 3. Create server and cluster clients by topological similarity (round 0)
server = pTopoFLServer(n_clusters=2, alpha_blend=0.3)
server.fit_clusters([c.get_descriptor() for c in clients])

# 4. Run 15 FL rounds
print("Running pTopoFL — 15 rounds")
print("-" * 45)
accs, aucs = run_rounds(clients, server, n_rounds=15, verbose=True)

print("-" * 45)
print(f"Final AUC:      {aucs[-1]:.3f}")
print(f"Final Accuracy: {accs[-1]:.3f}")
print(f"Flagged clients (last round): {server.round_logs[-1]['flagged']}")
