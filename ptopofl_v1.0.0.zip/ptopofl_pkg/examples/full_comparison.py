"""
examples/full_comparison.py
============================
Reproduce the 5-method comparison from the paper.

Methods: pTopoFL | FedAvg | FedProx | SCAFFOLD | pFedMe
Scenarios: Healthcare (8 clients, 2 adversarial) | Benchmark (10 clients)

Run:
    python examples/full_comparison.py

Expected output (seed=42, 15 rounds):
    Healthcare — pTopoFL AUC: 0.841
    Benchmark  — pTopoFL AUC: 0.910
"""

import numpy as np

from ptopofl import pTopoFLClient, pTopoFLServer, run_rounds
from ptopofl.data import make_healthcare_federated, make_benchmark_federated
from ptopofl.baselines import (
    FedAvgClient,   FedAvgServer,
    FedProxClient,  FedProxServer,
    SCAFFOLDClient, SCAFFOLDServer,
    pFedMeClient,   pFedMeServer,
    run_baseline_rounds,
)

N_ROUNDS = 15
SEED     = 42
SEP      = "=" * 55


def _run_ptopofl(client_data, n_rounds, seed):
    clients = [
        pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
                      d["X_test"],   d["y_test"], random_state=seed)
        for d in client_data
    ]
    server = pTopoFLServer(n_clusters=2, alpha_blend=0.3)
    server.fit_clusters([c.get_descriptor() for c in clients])
    _, aucs = run_rounds(clients, server, n_rounds=n_rounds)
    return aucs


def _run_baseline(ClientCls, ServerCls, client_data, n_rounds, seed, **kw):
    clients = [
        ClientCls(d["client_id"], d["X_train"], d["y_train"],
                  d["X_test"],   d["y_test"], random_state=seed, **kw)
        for d in client_data
    ]
    server = ServerCls()
    _, aucs = run_baseline_rounds(clients, server, n_rounds=n_rounds)
    return aucs


def run_scenario(name, client_data, n_rounds=15, seed=42):
    print(f"\n{SEP}")
    print(f"  {name}")
    print(SEP)

    results = {}

    print("  [1/5] pTopoFL ...")
    aucs = _run_ptopofl(client_data, n_rounds, seed)
    results["pTopoFL"] = aucs
    print(f"         Final AUC = {aucs[-1]:.4f}")

    print("  [2/5] FedAvg ...")
    aucs = _run_baseline(FedAvgClient, FedAvgServer,
                         client_data, n_rounds, seed + 100)
    results["FedAvg"] = aucs
    print(f"         Final AUC = {aucs[-1]:.4f}")

    print("  [3/5] FedProx (μ=0.1) ...")
    aucs = _run_baseline(FedProxClient, FedProxServer,
                         client_data, n_rounds, seed + 200, mu=0.1)
    results["FedProx"] = aucs
    print(f"         Final AUC = {aucs[-1]:.4f}")

    print("  [4/5] SCAFFOLD ...")
    aucs = _run_baseline(SCAFFOLDClient, SCAFFOLDServer,
                         client_data, n_rounds, seed + 300)
    results["SCAFFOLD"] = aucs
    print(f"         Final AUC = {aucs[-1]:.4f}")

    print("  [5/5] pFedMe (λ=15) ...")
    aucs = _run_baseline(pFedMeClient, pFedMeServer,
                         client_data, n_rounds, seed + 400, lam=15.0)
    results["pFedMe"] = aucs
    print(f"         Final AUC = {aucs[-1]:.4f}")

    print(f"\n  {'Method':<12} {'Final AUC':>10}")
    print(f"  {'-'*24}")
    for method, aucs in results.items():
        marker = " ← best" if aucs[-1] == max(r[-1] for r in results.values()) else ""
        print(f"  {method:<12} {aucs[-1]:>10.4f}{marker}")

    return results


if __name__ == "__main__":
    # Scenario A: Healthcare
    hc_data, _, _ = make_healthcare_federated(
        n_clients=8, adversarial_clients=[1, 5], random_state=SEED
    )
    hc_results = run_scenario("Healthcare (8 hospitals, 2 adversarial)",
                               hc_data, N_ROUNDS, SEED)

    # Scenario B: Benchmark
    bm_data, _, _ = make_benchmark_federated(n_clients=10, random_state=SEED)
    bm_results = run_scenario("Benchmark (10 clients, pathological non-IID)",
                               bm_data, N_ROUNDS, SEED)

    print(f"\n{SEP}")
    print("  SUMMARY")
    print(SEP)
    print(f"  {'Scenario':<30} {'pTopoFL':>8} {'FedProx':>8}")
    print(f"  {'-'*48}")
    hc_pt = hc_results["pTopoFL"][-1]
    hc_fp = hc_results["FedProx"][-1]
    bm_pt = bm_results["pTopoFL"][-1]
    bm_fp = bm_results["FedProx"][-1]
    print(f"  {'Healthcare':<30} {hc_pt:>8.4f} {hc_fp:>8.4f}  (+{(hc_pt-hc_fp)*100:.1f}pp)")
    print(f"  {'Benchmark':<30} {bm_pt:>8.4f} {bm_fp:>8.4f}  (+{(bm_pt-bm_fp)*100:.1f}pp)")
    print()
