"""
tests/test_ptopofl.py
=====================
Full test suite for pTopoFL.

Run with:
    pytest tests/ -v
    pytest tests/ -v --cov=ptopofl --cov-report=term-missing
"""

import numpy as np
import pytest

from ptopofl       import pTopoFLClient, pTopoFLServer, run_rounds
from ptopofl.tda   import (
    compute_topological_descriptor,
    descriptor_distance,
    wasserstein_distance_diagrams,
    persistence_entropy,
    diagram_amplitude,
    betti_curve,
)
from ptopofl.data  import make_healthcare_federated, make_benchmark_federated
from ptopofl.baselines import (
    FedAvgClient,   FedAvgServer,
    FedProxClient,  FedProxServer,
    SCAFFOLDClient, SCAFFOLDServer,
    pFedMeClient,   pFedMeServer,
    run_baseline_rounds,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def small_data():
    """50-sample binary classification dataset."""
    rng = np.random.RandomState(0)
    X   = rng.randn(50, 5)
    y   = (rng.rand(50) > 0.5).astype(float)
    return X, y


@pytest.fixture(scope="module")
def healthcare_data():
    return make_healthcare_federated(n_clients=4, random_state=42)


@pytest.fixture(scope="module")
def benchmark_data():
    return make_benchmark_federated(n_clients=4, random_state=42)


# ---------------------------------------------------------------------------
# TDA tests
# ---------------------------------------------------------------------------

class TestTDA:

    def test_descriptor_shape(self, small_data):
        X, _ = small_data
        d = compute_topological_descriptor(X, n_sample=30, random_state=0)
        assert d["feature_vector"].shape == (48,)

    def test_descriptor_reproducible(self, small_data):
        X, _ = small_data
        d1 = compute_topological_descriptor(X, random_state=0)
        d2 = compute_topological_descriptor(X, random_state=0)
        np.testing.assert_array_equal(d1["feature_vector"], d2["feature_vector"])

    def test_descriptor_nonnegative(self, small_data):
        X, _ = small_data
        d = compute_topological_descriptor(X)
        assert (d["feature_vector"] >= 0).all()

    def test_descriptor_keys(self, small_data):
        X, _ = small_data
        d = compute_topological_descriptor(X)
        for key in ["feature_vector", "h0_pairs", "h1_pairs",
                    "h0_entropy", "h1_entropy", "h0_amplitude", "h1_amplitude",
                    "betti0_curve", "betti1_curve", "thresholds"]:
            assert key in d, f"Missing key: {key}"

    def test_descriptor_distance_zero(self, small_data):
        X, _ = small_data
        d = compute_topological_descriptor(X)
        assert descriptor_distance(d, d) == pytest.approx(0.0, abs=1e-10)

    def test_descriptor_distance_range(self, small_data):
        X, _ = small_data
        rng  = np.random.RandomState(99)
        Y    = rng.randn(50, 5)
        d1   = compute_topological_descriptor(X)
        d2   = compute_topological_descriptor(Y)
        dist = descriptor_distance(d1, d2)
        assert 0.0 <= dist <= 2.0

    def test_persistence_entropy_empty(self):
        assert persistence_entropy([]) == 0.0

    def test_persistence_entropy_nonneg(self, small_data):
        X, _ = small_data
        d = compute_topological_descriptor(X)
        assert d["h0_entropy"] >= 0.0
        assert d["h1_entropy"] >= 0.0

    def test_diagram_amplitude_empty(self):
        assert diagram_amplitude([]) == 0.0

    def test_betti_curve_length(self, small_data):
        X, _ = small_data
        d = compute_topological_descriptor(X, n_thresholds=15)
        assert len(d["betti0_curve"]) == 15
        assert len(d["betti1_curve"]) == 15

    def test_wasserstein_same_diagram(self, small_data):
        X, _ = small_data
        d    = compute_topological_descriptor(X)
        w    = wasserstein_distance_diagrams(d["h0_pairs"], d["h0_pairs"])
        assert w == pytest.approx(0.0, abs=1e-6)

    def test_wasserstein_empty(self):
        assert wasserstein_distance_diagrams([], []) == 0.0

    def test_h0_essential_class(self, small_data):
        X, _ = small_data
        d  = compute_topological_descriptor(X)
        h0 = d["h0_pairs"]
        inf_pairs = [p for p in h0 if not np.isfinite(p[1])]
        assert len(inf_pairs) == 1, "H0 must have exactly one essential class"


# ---------------------------------------------------------------------------
# Client tests
# ---------------------------------------------------------------------------

class TestClient:

    def test_client_descriptor_keys(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40], X[40:], y[40:])
        desc = c.get_descriptor()
        for k in ["client_id", "feature_vector", "h0_entropy",
                  "h1_entropy", "h0_amplitude", "n_samples"]:
            assert k in desc

    def test_client_no_raw_data_in_descriptor(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40])
        desc = c.get_descriptor()
        # Descriptor must not contain X or y
        assert "X_train" not in desc
        assert "y_train" not in desc
        assert "gradient" not in desc

    def test_client_train_and_evaluate(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40], X[40:], y[40:])
        c.train_local()
        m = c.evaluate()
        assert 0.0 <= m["accuracy"] <= 1.0
        assert 0.0 <= m["auc"]      <= 1.0

    def test_client_untrained_evaluate(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40], X[40:], y[40:])
        m    = c.evaluate()
        assert m == {"accuracy": 0.0, "auc": 0.5}

    def test_client_get_params_untrained(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40])
        assert c.get_params() is None

    def test_client_get_params_trained(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40])
        c.train_local()
        p = c.get_params()
        assert p is not None
        assert "coef" in p and "intercept" in p and "n_samples" in p

    def test_client_set_params(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40])
        c.train_local()
        p = c.get_params()
        c2 = pTopoFLClient(1, X[:40], y[:40])
        c2.set_params(p)
        np.testing.assert_array_equal(c2.coef_,      c.coef_)
        np.testing.assert_array_equal(c2.intercept_, c.intercept_)

    def test_client_round_counter(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(0, X[:40], y[:40])
        assert c._round == 0
        c.train_local(); assert c._round == 1
        c.train_local(); assert c._round == 2

    def test_client_repr(self, small_data):
        X, y = small_data
        c    = pTopoFLClient(3, X, y)
        assert "pTopoFLClient" in repr(c)
        assert "untrained" in repr(c)


# ---------------------------------------------------------------------------
# Server tests
# ---------------------------------------------------------------------------

class TestServer:

    def test_fit_clusters_returns_labels(self, small_data):
        X, y = small_data
        clients = [pTopoFLClient(i, X, y) for i in range(4)]
        descs   = [c.get_descriptor() for c in clients]
        server  = pTopoFLServer(n_clusters=2)
        labels  = server.fit_clusters(descs)
        assert len(labels) == 4
        assert set(labels).issubset({0, 1})

    def test_aggregate_produces_cluster_models(self, small_data):
        X, y    = small_data
        clients = [pTopoFLClient(i, X[:40], y[:40], X[40:], y[40:]) for i in range(4)]
        server  = pTopoFLServer(n_clusters=2)
        server.fit_clusters([c.get_descriptor() for c in clients])
        for c in clients:
            c.train_local()
        cm, log = server.aggregate(clients, round_num=0)
        assert isinstance(cm, dict)
        for cid, params in cm.items():
            assert "coef" in params and "intercept" in params

    def test_run_rounds_auc_length(self, healthcare_data):
        client_data, _, _ = healthcare_data
        clients = [
            pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
                          d["X_test"],   d["y_test"])
            for d in client_data
        ]
        server = pTopoFLServer(n_clusters=2)
        server.fit_clusters([c.get_descriptor() for c in clients])
        accs, aucs = run_rounds(clients, server, n_rounds=5)
        assert len(accs) == 5
        assert len(aucs) == 5

    def test_run_rounds_auc_range(self, healthcare_data):
        client_data, _, _ = healthcare_data
        clients = [
            pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
                          d["X_test"],   d["y_test"])
            for d in client_data
        ]
        server = pTopoFLServer(n_clusters=2)
        server.fit_clusters([c.get_descriptor() for c in clients])
        _, aucs = run_rounds(clients, server, n_rounds=5)
        assert all(0.0 <= a <= 1.0 for a in aucs)

    def test_alpha_zero_equals_personalised(self, small_data):
        """α=0 should give cluster-only models without global blending."""
        X, y    = small_data
        clients = [pTopoFLClient(i, X[:40], y[:40], X[40:], y[40:]) for i in range(4)]
        server  = pTopoFLServer(n_clusters=2, alpha_blend=0.0)
        server.fit_clusters([c.get_descriptor() for c in clients])
        for c in clients:
            c.train_local()
        cm, _ = server.aggregate(clients)
        assert cm is not None

    def test_trust_weights_range(self, small_data):
        X, y    = small_data
        clients = [pTopoFLClient(i, X[:40], y[:40], X[40:], y[40:]) for i in range(5)]
        descs   = [c.get_descriptor() for c in clients]
        server  = pTopoFLServer()
        server.fit_clusters(descs)
        trust   = server._trust(descs)
        assert all(0.05 <= t <= 1.0 for t in trust)

    def test_cluster_params_helper(self, small_data):
        X, y    = small_data
        clients = [pTopoFLClient(i, X[:40], y[:40], X[40:], y[40:]) for i in range(4)]
        server  = pTopoFLServer(n_clusters=2)
        server.fit_clusters([c.get_descriptor() for c in clients])
        for c in clients:
            c.train_local()
        server.aggregate(clients)
        cp = server.cluster_params(0)
        assert cp is None or ("coef" in cp and "intercept" in cp)


# ---------------------------------------------------------------------------
# Data generator tests
# ---------------------------------------------------------------------------

class TestData:

    def test_healthcare_client_count(self):
        data, Xt, yt = make_healthcare_federated(n_clients=8)
        assert len(data) == 8

    def test_healthcare_client_keys(self):
        data, _, _ = make_healthcare_federated(n_clients=4)
        for d in data:
            for k in ["client_id", "X_train", "y_train",
                      "X_test", "y_test", "is_adversarial"]:
                assert k in d

    def test_healthcare_adversarial_flag(self):
        data, _, _ = make_healthcare_federated(
            n_clients=4, adversarial_clients=[0, 2]
        )
        assert data[0]["is_adversarial"] is True
        assert data[1]["is_adversarial"] is False
        assert data[2]["is_adversarial"] is True

    def test_healthcare_label_range(self):
        data, _, _ = make_healthcare_federated(n_clients=4)
        for d in data:
            assert set(np.unique(d["y_train"])).issubset({0.0, 1.0})

    def test_benchmark_client_count(self):
        data, _, _ = make_benchmark_federated(n_clients=6)
        assert len(data) == 6

    def test_benchmark_test_set(self):
        _, Xt, yt = make_benchmark_federated(n_clients=4)
        assert Xt.shape[0] == 500
        assert len(yt) == 500

    def test_data_reproducible(self):
        d1, _, _ = make_healthcare_federated(random_state=7)
        d2, _, _ = make_healthcare_federated(random_state=7)
        np.testing.assert_array_equal(d1[0]["X_train"], d2[0]["X_train"])


# ---------------------------------------------------------------------------
# Baseline tests
# ---------------------------------------------------------------------------

class TestBaselines:

    @pytest.mark.parametrize("ClientCls,ServerCls", [
        (FedAvgClient,   FedAvgServer),
        (FedProxClient,  FedProxServer),
        (SCAFFOLDClient, SCAFFOLDServer),
        (pFedMeClient,   pFedMeServer),
    ])
    def test_baseline_runs(self, small_data, ClientCls, ServerCls):
        X, y    = small_data
        clients = [ClientCls(i, X[:40], y[:40], X[40:], y[40:]) for i in range(4)]
        server  = ServerCls()
        accs, aucs = run_baseline_rounds(clients, server, n_rounds=3)
        assert len(accs) == 3
        assert len(aucs) == 3
        assert all(0.0 <= a <= 1.0 for a in aucs)

    def test_scaffold_uses_control_variate(self, small_data):
        X, y    = small_data
        clients = [SCAFFOLDClient(i, X[:40], y[:40]) for i in range(3)]
        server  = SCAFFOLDServer()
        run_baseline_rounds(clients, server, n_rounds=3)
        assert server.global_control is not None

    def test_pfedme_personalised_model(self, small_data):
        """pFedMe personalised θ_k should differ from global w."""
        X, y = small_data
        c    = pFedMeClient(0, X[:40], y[:40], X[40:], y[40:], lam=15.0)
        s    = pFedMeServer()
        run_baseline_rounds([c], s, n_rounds=5)
        # Personalised coef_ vs global w_coef_ should differ after training
        if c.coef_ is not None and c.w_coef_ is not None:
            assert not np.allclose(c.coef_, c.w_coef_), \
                "Personalised model should differ from global model"


# ---------------------------------------------------------------------------
# Integration test: full 5-method comparison
# ---------------------------------------------------------------------------

class TestIntegration:

    def test_ptopofl_vs_fedavg_healthcare(self):
        """pTopoFL should achieve AUC > 0.5 on the healthcare scenario."""
        data, _, _ = make_healthcare_federated(
            n_clients=4, adversarial_clients=[1], random_state=42
        )
        clients = [
            pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
                          d["X_test"],   d["y_test"])
            for d in data
        ]
        server = pTopoFLServer(n_clusters=2, alpha_blend=0.3)
        server.fit_clusters([c.get_descriptor() for c in clients])
        _, aucs = run_rounds(clients, server, n_rounds=5)
        assert aucs[-1] > 0.5, f"Expected AUC > 0.5, got {aucs[-1]:.3f}"

    def test_single_client_edge_case(self):
        """pTopoFL must handle K=1 without crashing."""
        rng = np.random.RandomState(0)
        X   = rng.randn(40, 5)
        y   = (rng.rand(40) > 0.5).astype(float)
        c   = pTopoFLClient(0, X[:32], y[:32], X[32:], y[32:])
        s   = pTopoFLServer(n_clusters=1)
        s.fit_clusters([c.get_descriptor()])
        c.train_local()
        s.aggregate([c])
        m = c.evaluate()
        assert "auc" in m

    def test_round_logs_populated(self, healthcare_data):
        client_data, _, _ = healthcare_data
        clients = [
            pTopoFLClient(d["client_id"], d["X_train"], d["y_train"],
                          d["X_test"],   d["y_test"])
            for d in client_data
        ]
        server = pTopoFLServer(n_clusters=2)
        server.fit_clusters([c.get_descriptor() for c in clients])
        run_rounds(clients, server, n_rounds=3)
        assert len(server.round_logs) == 3
        for log in server.round_logs:
            assert "round" in log
            assert "cluster_labels" in log
            assert "trust_weights" in log
